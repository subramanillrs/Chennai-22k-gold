# Chennai 22K Gold Tracker — 3-year history

This version adds a one-time 36-month backfill from LiveChennai's daily Chennai Standard Gold (22K) history and then continues adding genuine live rate changes.

Important: LiveChennai's historical page explicitly states that it does not guarantee accuracy/completeness. The app keeps source attribution visible.

After replacing `.github/workflows/main.yml` with the supplied workflow, run it manually once. It will:
1. Backfill the last 36 calendar months when history.json is empty/small.
2. Fetch the current Chennai 22K rate.
3. Record only genuine rate changes.
4. Commit `data/live.json` and `data/history.json`.

The PWA reads both files same-origin and refreshes every five minutes while open.
